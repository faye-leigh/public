/* Copyright 2024 Neil Kirby, not for disclosure without permission */

bool ball_is_on_field(struct Ball *ball);
bool do_everything();
