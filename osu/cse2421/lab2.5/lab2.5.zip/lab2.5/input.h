/* Copyright 2024 Neil Kirby, not for disclosure without permission */

bool good_input( struct Ball *ball, struct Block *block,struct Paddle *paddle);
