// COpyright 2024 Neil Kirby.  Not for disclosure without permission
//

struct Ball {
	int color;
	double x_position, y_position, x_velocity, y_velocity;
};

struct Paddle {
	int color, score;
	double x_position, size;
};

struct Block {
	int color;
	double x_position, y_position;
};

