/* Neil Kirby */

int microsleep(unsigned int microseconds);
int millisleep(unsigned int milliseconds);
double now();
