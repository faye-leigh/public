
long fx( long p1, long p2, long p3,
	long p4, long p5, long p6,
	long p7)
{
	long rval;

	/* render only the following line of C in assembler */
	rval = p1 + p7;

	return rval;
}
