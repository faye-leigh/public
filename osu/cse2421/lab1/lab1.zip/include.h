/* Faye Leigh */
#define INIT 1