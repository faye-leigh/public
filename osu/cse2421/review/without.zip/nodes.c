
struct Node {
	void *data;
	struct Node *left, *right;
	};

/* do the entire function in assembler */
/* from the label to the return */
long count(struct Node *ptr)
{
	long rval = 0;

	if(ptr)
	{
	    rval = 1;	/* count the node itself */
	    /* add the child counts */
	    rval += count(ptr->left);
	    rval += count(ptr->right);
	}
	return rval;
}

