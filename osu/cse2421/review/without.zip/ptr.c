
/* be able to get into and out of memory with a pointer */

void inc(int *ip)
{

	/* think this one over carefully, it hides a bunch of stuff */
	*ip += 1;

}
