/* Copyright 2024 Faye Leigh */
/*    OSU CSE 2421 - AU24    */

#define SEC_INTERVAL 32
#define DELTA_T (1.0 / SEC_INTERVAL)