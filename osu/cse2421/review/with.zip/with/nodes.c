
struct Node {
	void *data;
	struct Node *left, *right;
	};

/* do the entire function in assembler */
long count(struct Node *ptr)
{
	long rval = 0;

	if(ptr)
	{
	    rval = 1;	/* count the node itself */
	    /* add the child counts */
	    rval += count(ptr->left);
	    rval += count(ptr->right);
	}
	return rval;
}

count:				# points off if you forget he labe when I 
				# ask for a funciton
	pushq %rbp
	movq %rsp, %rbp		# stack frame will be required for functions
				# assumed to be there for other questions

	xorq	%rax, %rax	# in case I don't have a node
	testq	%rdi, %rdi	# is my pointer zero?
	jz	done		# no pointer, no work to do

	pushq	%rbx		# we make function calls and have 2 values that
	pushq	%r12		# need to survive the calls

	movq	%rdi, %rbx	# survive the funciton call pointer
	movq	$1, %r12	# count the current node


	movq	8(%rbx), %rdi	# go to memory for the pointer
	call count		# left count
	addq %rax, %r12		# add the left count


	movq 16(%rbx), %rdi	# go to memory for right pointer
	call count		# right count
	addq %r12, %rax		# no more calls, put sum where I really want it


	popq %r12		# make sure the order is right
	popq 	%rbx

done:
	leave			# required for complete functions, not for 
				# single lines fo code
	ret

