/* Copyright 2024 Neil Kirby, not for disclosure without permission */

bool init();
int main();
void teardown();
