
/* given a struct, get any elelemnt or the address of any element 
** THis means you have to know how structs are laid out, alignment, 
** padding etc. */

struct Record {
    char name[15];
    short scores[2][6];
    int win, loss, tie;
};

void fx( struct Record *ptr)
{

	int i, *ip;
	short *sp;

	/* be able to do any of the next 4 lines */

	i = ptr->win;
	ip = &ptr->tie;

	i = ptr->scores[0][3];
	sp = &ptr->scores[1][1];
	
}
