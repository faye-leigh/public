void wtest( char *bytePointer, long count)
{
	/* render the entire while loop in assembler */
	while(count)
	{
		count--;
		bytePointer[count] = 0;
	}


	/*
loop:
	testq %rsi, %rsi
	jz done

	decq %rsi
	movb $0, (%rdi, %rsi)

	jmp loop
done:
	*/
}
