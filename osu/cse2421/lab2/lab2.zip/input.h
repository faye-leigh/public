/* Faye Leigh */

bool inputBall(double ball[]) ;
bool inputBallLoop(double ball[], int count) ;
bool inputBlock(double block[]) ;
bool inputBlockLoop(double block[], int count) ;
bool inputPaddle(double paddle[]) ;
bool inputPaddleLoop(double paddle[], int count) ;
