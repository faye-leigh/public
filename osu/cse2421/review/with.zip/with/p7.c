
long fx( long p1, long p2, long p3,
	long p4, long p5, long p6,
	long p7)
{
	long rval;

	/* render the following line of C in assembler */
	rval = p1 + p7;

	/*
	movq %rdi, %rax		# rax = p1
	addq 16(%rbp), %rax	# add p7 to that
	*/

	return rval;
}
