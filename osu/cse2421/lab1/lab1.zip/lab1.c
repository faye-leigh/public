/* Faye Leigh */

#include <stdio.h>
#include "include.h"
#include "lab1.h"

double foo(double x)
{
    return 2.0 * x;
}

int timesTwo(int x)
{
    return 2 * x;
}

int main()
{
    int i = INIT, j;

    printf("Before, i=%d\n", i);
    j = timesTwo(i);
    printf("After, j=%d\n", j);
    /* Returning 0 to the system signifies no errors */
    return 0;
}
