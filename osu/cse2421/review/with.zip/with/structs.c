
/* given a struct, get any elelemnt or the address of any element 
** THis means you have to know how structs are laid out, alignment, 
** padding etc. */

struct Record {
    char name[15];
    short scores[2][6];
    int win, loss, tie;
};

void fx( struct Record *ptr)
{

	int i, *ip;
	short *sp;

	i = ptr->win;

	/*
	movl 40(%rdi), %eax
	*/

	ip = &ptr->tie;

	/*
	leaq 48(%rdi), %rax
	*/

	/* be able to do these, they are more involved */
	i = ptr->scores[0][3];
	sp = &ptr->scores[1][1];
	
}
