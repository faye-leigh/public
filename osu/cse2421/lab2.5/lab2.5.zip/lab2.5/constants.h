// Copyright 2024 Neil Kirby, not for dosclosure without written permission
//constants.h

#define DELTA_T (1.0/32.0)