
/* be able to get into and out of memory with a pointer */

void inc(int *ip)
{

	/* think this one over carefully, it hides a bunch of stuff */
	/* just do this one line */
	*ip += 1;

	/*
	addl $1, (%rdi) 
	*/

}
