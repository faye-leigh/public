/* Faye Leigh */

double foo(double x);
int main();
int timesTwo(int x);
